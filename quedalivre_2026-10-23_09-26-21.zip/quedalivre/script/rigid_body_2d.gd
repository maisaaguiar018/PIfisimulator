extends RigidBody2D

var altura_inicial: float = 0.0
var tempo_decorrido: float = 0.0
var em_queda: bool = false
var clicando = false
var posicao_inicial_objeto: Vector2

# --- AJUSTE DA GRAVIDADE ESCOLAR ---
var g: float = 10.0 

# --- TAXA DE CONVERSÃO AJUSTADA ---
var PIXELS_POR_METRO: float = 50.0

@onready var chao_node = $"../Chão"
@onready var grafico_node = $"../CaixaGrafico/Grafico"
@onready var caixa_grafico = $"../CaixaGrafico"
@onready var efeito_impacto = $"../EfeitoImpacto"

# REFERÊNCIAS DOS SPRITES (Ajuste o nome do Sprite2D se o seu for diferente)
@onready var sprite_normal = $Sprite2D
@onready var anim_impacto = $AnimacaoImpacto

var grafico_escala_tempo: float = 150.0   
var grafico_escala_altura: float = 20.0 

func _ready() -> void:
	freeze = true
	contact_monitor = true
	max_contacts_reported = 1
	posicao_inicial_objeto = global_position 
	
	if grafico_node:
		grafico_node.clear_points()
		grafico_node.position = Vector2.ZERO
		
	# Estado inicial dos sprites
	if anim_impacto:
		anim_impacto.visible = false
	if sprite_normal:
		sprite_normal.visible = true

func _on_input_event(_viewport: Node, event: InputEvent, _shape_idx: int) -> void:
	if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
		clicando = event.pressed 
		freeze = event.pressed 
		if event.pressed:
			em_queda = false
			tempo_decorrido = 0.0
			if grafico_node:
				grafico_node.clear_points()

func _input(event: InputEvent) -> void:
	if not chao_node: return
	var chao_y = chao_node.global_position.y
	
	if clicando and event is InputEventMouseMotion:
		global_position = get_global_mouse_position()
		
		var altura_pixels = chao_y - global_position.y
		var altura_real = altura_pixels / PIXELS_POR_METRO
		if altura_real < 0: altura_real = 0
			
		$"../altura".text = "Altura: %.2f m" % altura_real
		$"../tempo".text = "Tempo: 0.00 s"
		$"../velocidade".text = "Velocidade: 0.00 m/s"
		
		var new_transform = global_transform
		new_transform.origin = get_global_mouse_position()
		PhysicsServer2D.body_set_state(get_rid(), PhysicsServer2D.BODY_STATE_TRANSFORM, new_transform)
		
	if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT and not event.pressed:
		if clicando:
			clicando = false
			freeze = false
			em_queda = true
			tempo_decorrido = 0.0
			altura_inicial = (chao_y - global_position.y) / PIXELS_POR_METRO
			
			if grafico_node:
				grafico_node.clear_points()

func _physics_process(delta: float) -> void:
	if em_queda:
		if get_contact_count() > 0 and tempo_decorrido > 0.02:
			em_queda = false
			if altura_inicial > 0:
				tempo_decorrido = sqrt((2 * altura_inicial) / g)
				var vel_final = g * tempo_decorrido
				$"../altura".text = "Altura: 0.00 m"
				$"../tempo".text = "Tempo: %.2f s" % tempo_decorrido
				$"../velocidade".text = "Velocidade: %.2f m/s" % vel_final
				adicionar_ponto_ao_grafico(tempo_decorrido, 0.0)
				
				# 1. DISPARA AS PARTÍCULAS DO CHÃO
				if efeito_impacto:
					efeito_impacto.global_position = global_position
					efeito_impacto.emitting = false
					efeito_impacto.emitting = true
					efeito_impacto.restart()
				
				# 2. TROCA PARA A ANIMAÇÃO DE IMPACTO
				if anim_impacto and sprite_normal:
					sprite_normal.visible = false  # Esconde o objeto normal
					anim_impacto.visible = true    # Mostra a animação
					anim_impacto.play("impacto")   # Toca os frames do impacto
		else:
			tempo_decorrido += delta
			
			var vel_atual = g * tempo_decorrido
			var altura_atual = altura_inicial - (0.5 * g * pow(tempo_decorrido, 2))
			if altura_atual < 0: altura_atual = 0
			
			$"../altura".text = "Altura: %.2f m" % altura_atual
			$"../tempo".text = "Tempo: %.2f s" % tempo_decorrido
			$"../velocidade".text = "Velocidade: %.2f m/s" % vel_atual
			
			adicionar_ponto_ao_grafico(tempo_decorrido, altura_atual)

func adicionar_ponto_ao_grafico(t: float, h: float) -> void:
	if not grafico_node or not caixa_grafico: return
	
	var local_x = t * grafico_escala_tempo
	var altura_caixa = caixa_grafico.size.y
	var local_y = altura_caixa - (h * grafico_escala_altura)
	
	if local_x < 0: local_x = 0
	if local_x > caixa_grafico.size.x: local_x = caixa_grafico.size.x
	
	if local_y > altura_caixa: local_y = altura_caixa 
	if local_y < 0: local_y = 0 
	
	grafico_node.add_point(Vector2(local_x, local_y))

# --- REINICIAR (RESTAURA OS SPRITES) ---
func _on_botao_reiniciar_pressed() -> void:
	em_queda = false
	clicando = false
	freeze = true 
	
	linear_velocity = Vector2.ZERO
	angular_velocity = 0.0
	global_position = posicao_inicial_objeto
	
	if grafico_node:
		grafico_node.clear_points()
	
	if efeito_impacto:
		efeito_impacto.emitting = false
		
	
	if anim_impacto and sprite_normal:
		anim_impacto.stop()
		anim_impacto.visible = false
		sprite_normal.visible = true
	
	if chao_node:
		var chao_y = chao_node.global_position.y
		var altura_real = (chao_y - global_position.y) / PIXELS_POR_METRO
		$"../altura".text = "Altura: %.2f m" % altura_real
		$"../tempo".text = "Tempo: 0.00 s"
		$"../velocidade".text = "Velocidade: 0.00 m/s"
