extends Control




func _ready() -> void:
	pass 
func change_scene(scene_path: String) -> void:
	get_tree().change_scene_to_file(scene_path)


func _process(_delta: float) -> void:
	if $button_mru.button_pressed:
		change_scene("res://scenes/mru/Introdução_Mru.tscn")
	
