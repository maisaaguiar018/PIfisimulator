extends Button
func _pressed():
	Global.inicio = false
	Global.tempo_queda = 0.0
	Global.distancia_queda = 0.0
	Global.velocidade_queda = 0.0
	
