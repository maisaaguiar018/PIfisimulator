extends Button


func _pressed():
	Global.inicio = true
