extends RigidBody2D


func _physics_process(delta):
	if Global.inicio:
		linear_velocity.y += Global.gravidade * delta
