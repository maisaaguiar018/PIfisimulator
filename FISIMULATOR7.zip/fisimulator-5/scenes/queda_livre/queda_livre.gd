extends Node2D

func _ready():
	Global.tempo_queda = 0.0
	Global.distancia_queda = 0.0
	Global.velocidade_queda = 0.0


func _physics_process(delta):
	if Global.inicio:
		Global.tempo_queda += delta

		Global.velocidade_queda = Global.gravidade * Global.tempo_queda

		Global.distancia_queda = (Global.gravidade * Global.tempo_queda * Global.tempo_queda) / 2
		$Camera2D.position.y = $passaro.position.y

	$CanvasLayer/tempo.text = "T = %.2f s" % Global.tempo_queda
	$CanvasLayer/velocidade.text = "V = %.2f m/s" % Global.velocidade_queda







func change_scene(scene_path: String) -> void:
	get_tree().change_scene_to_file(scene_path)


func _process(_delta: float) -> void:\
	if $CanvasLayer/VoltarMenu .button_pressed:
		change_scene("res://scenes/menu.tscn")
