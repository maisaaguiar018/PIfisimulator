# Dependencies
GNU Make
Godot 4.6
